#include "GetAndSet.h"



GetAndSet::GetAndSet() {
}


void GetAndSet::setPosition(int x, int y) {
	_x = x;
	_y = y;
}

